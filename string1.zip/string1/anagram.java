

import java.util.Arrays;

public class anagram 
{
    public static void main(String[] args) 
    {
        String str1="listen";
        String str2="silent";


        char []ar1=str1.toCharArray();
        char []ar2=str2.toCharArray();

        Arrays.sort(ar1);
        Arrays.sort(ar2);

        if(Arrays.equals(ar1, ar2))
        {
            System.out.println("It's an Anagram");
        }
        else 
        {
            System.out.println("Its not an Anagram");
        }
    }
    
}