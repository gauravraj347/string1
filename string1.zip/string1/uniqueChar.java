import java.util.HashSet;
import java.util.Set;

public class uniqueChar {

    public static boolean hasUniqueCharacters(String inputString) {
        Set<Character> uniqueCharacters = new HashSet<>();
        for (char ch : inputString.toCharArray()) {
            if (!uniqueCharacters.add(ch)) {
                return false;
            }
        }

        return true;
    }

    public static void main(String[] args) {
        String inputStr = "abcdefg";
        if (hasUniqueCharacters(inputStr)) {
            System.out.println("The string has all unique characters.");
        } else {
            System.out.println("The string has duplicate characters.");
        }
    }
}
