import java.util.HashMap;
import java.util.Map;

public class maxChar {

    public static char findMaxOccurringCharacter(String inputString) {
        Map<Character, Integer> charFrequency = new HashMap<>();

        for (char ch : inputString.toCharArray()) {
            charFrequency.put(ch, charFrequency.getOrDefault(ch, 0) + 1);
        }

        char maxChar = ' ';
        int maxFrequency = 0;

        for (Map.Entry<Character, Integer> entry : charFrequency.entrySet()) {
            if (entry.getValue() > maxFrequency) {
                maxChar = entry.getKey();
                maxFrequency = entry.getValue();
            }
        }

        return maxChar;
    }

    public static void main(String[] args) {
        String inputStr = "gaurav";
        char maxChar = findMaxOccurringCharacter(inputStr);

        System.out.println("The maximum occurring character is: " + maxChar);
    }
}
